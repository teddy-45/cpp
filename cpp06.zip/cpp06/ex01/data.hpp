#ifndef DATA_HPP
#define DATA_HPP

#include <iostream>

struct Data {
    int value;
    std::string name;
};

#endif
 